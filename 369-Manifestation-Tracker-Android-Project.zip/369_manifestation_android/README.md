# 369 Manifestation Tracker — Android starter project

This is a recreated Android Studio project wrapping a bundled, offline-first 369 tracker web UI in an Android WebView.

## Included
- Morning 3, afternoon 6, evening 9 checklist
- Editable intention and affirmation
- Ten gratitude notes
- Daily completion progress
- Local storage for saved entries and progress
- Portrait layout and Android back-button handling

## Important notes
- This is a starter project ZIP, not a compiled APK.
- Automatic reminders/notifications are not implemented in this version.
- To build an APK, open the project in Android Studio on a computer, or adapt the bundled web UI to an Expo project and use EAS cloud build.
- Android Gradle Plugin/Kotlin versions are declared in `build.gradle.kts`; Gradle wrapper files are not bundled.
