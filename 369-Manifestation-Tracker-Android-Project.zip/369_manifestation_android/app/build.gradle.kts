plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.sauravmidha.manifestation369"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.sauravmidha.manifestation369"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
